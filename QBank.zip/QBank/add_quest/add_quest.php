<?php 
ob_start();
session_start();
include("../includes/db.php");
include("../includes/function.php");

if(isset($_POST['add_quest'])){
	$branch1 = $branch = $_POST['branch'];
	$co1 = $co = $_POST['co'];
	$sem1 = $sem = $_POST['sem'];
	$sub = "sem-".$sem;
	$sub1 = $sub = $_POST[$sub];
	
	/*$query = "select * from it where sem ='$sem' and sub ='$sub'";
	$result = mysqli_query($conn,$query);
	$id = array();
	while($row = mysqli_fetch_assoc($result)){
		 $quest_id = array($row['id']);
		$id = array_merge($id,$quest_id);
	}
	$_SESSION['id'] = $id;*/
		
		 $_SESSION['sem'] = $sem;
		 $_SESSION['sub'] = $sub;
		 $_SESSION['co'] = $co;
		 $_SESSION['branch'] = $branch;
	
	
		
}
	global $sem1; 
	global $sub1; 
	global $co1; 
	global $branch1; 



if(isset($_POST['new_quest'])){
	$quest = string_check($_POST['quest']);
	global $sem; 
	global $sub; 
	global $co; 
	global  $branch; 
	$branch = strtolower($branch); 
	echo $sem;
	
	$query = "INSERT INTO $branch (`sem`, `sub`, `quest`, `co`) VALUES ( $sem, $sub, $quest, $co);";
	$result = mysqli_query($conn,$query);
	
	query_check($result);
	
	echo '<div class="alert alert-success alert-dismissible fade show">
            <button class="close" data-dismiss="alert" type="button">
                <span>&times;</span>
            </button>
            	Question Added Successfully!!
        </div>';
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<title>Add Question</title>
	<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css'>
</head>

<body>
	<div class="jumbotron">
		<h1 class="display-4 ">
			<p class="text-center">
				<span class="text-left">Branch:
					<?php echo  $branch1."-".$sem1; ?></span>
				<span class="text-right">Subject:
					<?php echo  $sub1;?></span>
				<span class="text-right">CO:
					<?php echo  $co1;?></span>
			</p>

		</h1>
	</div>
	<div class="container">

		<form action="" method="post">
			<div class="row">
				<textarea name="quest" class="" id="quest" cols="30" rows="10">



			</textarea>
			</div>
			<br>

			<button name="new_quest" class="btn btn-danger">Add Question</button>
		</form>

	</div>
	<script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>
	<script>
		tinymce.init({
			selector: 'textarea'
		});

	</script>
	<script src='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js'></script>
	<script src='//code.jquery.com/jquery-1.11.2.min.js'></script>
</body>

</html>
