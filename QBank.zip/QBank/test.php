<?php
    
    $query = "SELECT * FROM donation WHERE purpose=`ngo`";

?>


<html>
<head>
   
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
    </style>
</head>

  <body><div class="container"><br>
  <br>
  <br>
  <br>
  
  <!-- display -->
   <div class="row">
    <div class="col-sm-4 jumbotron">
    <img src="login/images/bg-01.jpg" alt="" height="100px" width="150px"><br>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquam nam, quo eaque qui hic sed sint. Nihil similique ducimus inventore magnam in, quidem sequi, omnis, ab quisquam eveniet nam aliquam!</p>
    </div>
    <div class="col-sm-4">
    <img src="login/images/bg-01.jpg" alt="" height="100px" width="150px"><br>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Veniam, culpa accusamus nam distinctio aperiam odio velit nobis veritatis optio. Animi nisi rem optio error accusamus amet, ducimus non, tempore enim.</p>
    </div>
    <div class="col-sm-4 jumbotron">
    <img src="login/images/bg-01.jpg" alt="" height="100px" width="150px"><br>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Veniam, culpa accusamus nam distinctio aperiam odio velit nobis veritatis optio. Animi nisi rem optio error accusamus amet, ducimus non, tempore enim.</p>
    </div>
    
    
    <!-- dropdown -->
    <select name="purpose" id="">
        <option value="calamities">Calamities</option>
        <option value="ngo">Ngo</option>
        <option value="donations">Donations</option>
    </select>
    
    
    
    
</div>
      </div>
    </body>
       </html>