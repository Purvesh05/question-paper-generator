<html>
    <head>
        
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">

    <!-- Title Page-->
    <title>QBank</title>

 <?php include "includes/links.php"; ?>
    <!-- Favicon -->
    <link rel="icon" type="image/png" sizes="32x32" href="../img/bg-img/favicon-32x32.png">

    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">
    <style>
        body{
            background-color: #fdf5e8;
        }
        </style>
    </head>
    <body>
        <div class="row">
            <div class="col-md-12">
                <h1 style="text-align:center">QBank academic planner</h1>
            </div>
        </div><br><br>
        <div class="row">
            <div class="col-lg-3">
                <p>     </p>
            </div>
            <div class="col-lg-6">
                <iframe src="https://calendar.google.com/calendar/embed?height=600&amp;wkst=2&amp;bgcolor=%23ffffcc&amp;src=6kqksodvj98u6o4clhf17o8eas%40group.calendar.google.com&amp;color=%238D6F47&amp;ctz=Asia%2FCalcutta" style="border:solid 1px #777" width="800" height="600" frameborder="0" scrolling="no"></iframe>
            </div>
            <div class="col-lg-3">
                <p>    </p>
            </div>
        </div>
    </body>
</html>