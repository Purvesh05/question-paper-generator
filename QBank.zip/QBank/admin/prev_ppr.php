
<?php
include("config/config.php");
if ($_REQUEST['submit'] == "Submit")
{
	//Here your submit code will come
}
//Ajax code
if ($_REQUEST['load_state'] == 1)
{
	$country_id = $_REQUEST['val'];
	$state_query = mysql_query("select state_id, state from state where country_id = '".$country_id."' ");
	
	$select_element = 'State : <select id="state" name="state" onChange="showCity(this.value)"><option value="">Choose</option>';
	while($fetch_state = mysql_fetch_array($state_query))
	{
		
		$select_element.="<option value=".$fetch_state[0].">".$fetch_state[1]."</option>";
	 }
	 $select_element.='</select>&nbsp;';
	 echo $select_element;
	 exit();
}
if ($_REQUEST['load_city'] ==1)
{
	$state_id = $_REQUEST['values'];
	$city_query = mysql_query("select city_id, city from city where state_id = '".$state_id."' ");
	$select_element = 'City : <select id="city" name="city"><option value="">Choose</option>';
	while($fetch_city = mysql_fetch_array($city_query))
	{
		
		$select_element.="<option value=".$fetch_city[0].">".$fetch_city[1]."</option>";
	 }
	 $select_element.='</select>&nbsp;';
	 echo $select_element;
	exit();
}
//EO //Ajax code
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<title>Title of the document</title>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript">
function showState(val)
{
	//alert (val);
	$.get('', {load_state:1, val:val}, function(data)
	{
		//Put an animated GIF image insight of content
		$("#state_display").html('<img src="images/ajax-loader.gif" />');
		$("#state_display").html(data);
		$("#state_display").show();
		
	}
	);
}
function showCity(values)
{
	//alert (values);
	$.get('',{load_city:1, values:values}, function (data)
	{
			$("#city_display").html('<img src="images/ajax-loader.gif" />');
			$("#city_display").html(data);
			$("#city_display").show();		
	});
}
</script>
<style type="text/css">
#country_display{float:left;}
#state_display{float:left;}
#city_display{float:left;}
</style>
</head>
<body>
<div id="frm">
	<form method="post" action="">
	<div id="country_display">
			Country : <select id="country" name="country" onChange="showState(this.value)">
		<option value="">Choose</option>
		<?php
			echo $sql="select country_id, country from countries";
			$res=mysql_query($sql) or die(mysql_error());
				
			while($row=mysql_fetch_array($res))
			{	
				echo "<option value=".$row[0].">".$row[1]."</option>";
			}
	
		?>
		</select>&nbsp;
		</div>
			
		<div id="state_display">
		 State : <select id="state" name="state" onChange="showCity(this.value)">
		<option value="">Choose</option>
		<?php
			echo $sql="select state_id, state from state";
			$res=mysql_query($sql) or die(mysql_error());
				
			while($row=mysql_fetch_array($res))
			{	
				echo "<option value=".$row[0].">".$row[1]."</option>";
			}
		?>
		</select>&nbsp;
		</div>
		<div id="city_display">
		City : <select id="city" name="city">
		<option value="">Choose</option>
		<?php
			echo $sql="select city_id, city from city";
			$res=mysql_query($sql) or die(mysql_error());
				
			while($row=mysql_fetch_array($res))
			{	
				echo "<option value=".$row[0].">".$row[1]."</option>";
			}
		?>
		</select>
		</div>
	</form>
<div>
	
<input type="submit" value="Submit" name="submit" />
</div>
</body>
</html>