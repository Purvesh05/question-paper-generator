<?php $conn = mysqli_connect("localhost","id7507253_aws","12345","id7507253_aws");
if(mysqli_connect_error()){
	echo "error in connection";
}
?>