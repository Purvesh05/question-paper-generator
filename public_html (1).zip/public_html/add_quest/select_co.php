<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<title>QBank</title>
	<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css'>
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
	background-color: #d6d9c3;
}

.topnav {
  overflow: hidden;
  background-color: #141414;
}

.topnav a {
  float: left;
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: rgba(239, 233, 233, 0.54);
  color: black;
}

.active {
  background-color: #4fea55;
  color: black;
}

.topnav .icon {
  display: none;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child) {display: none;}
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
}
</style>
</head>

<body>
<div class="topnav" id="myTopnav">
	<a href="" class="active"><b>ELiT</b></a>
	<a href="../admin/index.php"><b>Dashboard</b></a>
	<a href="../admin/prev_ppr.php"><b>Previous papers</b></a>
	<a href="../admin/calendar.php"><b>Planner</b></a>
	<a href="../admin/search.php"><b>Google</b></a>
	<a href="../login/logout.php" style="align: end"><b>Logout</b></a>
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
</div>

<br>
<br>
<br>
	<div class="container">
		<div class="row">
			<form action="add_quest.php" method="post">
				<h4 style="text-align: center">Select Branch,Semester,Subject and CO for filling the Question</h4>
				<br>
				<label for="">Branch: </label>
				<select name="branch" class="form-control" id="">
					<option value="Not Entered">--</option>
					<option value="it">IT</option>
					<option value="comps">COMPS</option>
					<option value="mech">MECH</option>
					<option value="elec">ELEC</option>
					<option value="extc">EXTC</option>
				</select>
				<label for="">Semester</label>
				<select class="sem form-control" name="sem">
					<option value="Not Entered">--</option>
					<option value="1">SEM-1</option>
					<option value="2">SEM-2<option>
					<option value="3">SEM-3</option>
					<option value="4">SEM-4</option>
					<option value="5">SEM-5</option>
					<option value="6">SEM-6</option>
					<option value="7">SEM-7</option>
					<option value="8">SEM-8</option>
				</select><br><br>


				<label for="Subject">Subject:</label>



				<select class="sem-1 form-control" name="sem-1">
					<label>Sem-1</label>
					<option value="Not Entered">--</option>
					<option value="1">Sem-1 sub1 </option>
					<option value="2">Sem-1 sub2</option>
					<option value="3">Sem-1 sub3</option>
				</select>


				<select class="sem-2 form-control" name="sem-2">
					<label>Sem-2</label>
					<option value="Not Entered">--</option>
					<option value="1">Sem-2 sub1 </option>
					<option value="2">Sem-2 sub2</option>
					<option value="3">Sem-2 sub3</option>
				</select>

				<select class="sem-3 form-control " name="sem-3">
					<label>Sem-3</label>
					<option value="Not Entered">--</option>
					<option value="1">Sem-3 sub1 </option>
					<option value="2">Sem-3 sub2</option>
					<option value="3">Sem-3 sub3</option>
				</select>

				<select class="sem-4 form-control" name="sem-4">
					<label>Sem-4</label>
					<option value="Not Entered">--</option>
					<option value="1">Sem-4 sub1 </option>
					<option value="2">Sem-4 sub2</option>
					<option value="3">Sem-4 sub3</option>
				</select>
				<select class="sem-5 form-control" name="sem-5">
					<label>Sem-5</label>
					<option value="Not Entered">--</option>
					<option value="CNS">CNS</option>
					<option value="MEP">MEP</option>

				</select>
				<select class="sem-6 form-control" name="sem-6">
					<label>Sem-6</label>
					<option value="Not Entered">--</option>
					<option value="1">Sem-6 sub1 </option>
					<option value="2">Sem-6 sub2</option>
					<option value="3">Sem-6 sub3</option>
				</select>
				<select class="sem-7 form-control" name="sem-7">
					<label>Sem-7</label>
					<option value="Not Entered">--</option>
					<option value="1">Sem-7 sub1 </option>
					<option value="2">Sem-7 sub2</option>
					<option value="3">Sem-8 sub3</option>
				</select>
				<select class="sem-8 form-control" name="sem-8">
					<label>Sem-8</label>
					<option value="Not Entered">--</option>
					<option value="1">Sem-8 sub1 </option>
					<option value="2">Sem-8 sub2</option>
					<option value="3">Sem-8 sub3</option>
				</select>
				<br>
				<br>
				<label for="">CO(Chapter): </label>
				<select class="co form-control" name="co">
					<option value="Not Entered">--</option>
					<option value="1">CO1</option>
					<option value="2">CO2</option>
					<option value="3">CO3</option>
					<option value="4">CO4</option>
					<option value="5">CO5</option>
					<option value="6">CO6</option>
				</select>
				<br>
				<br>


				<input class="btn btn-success" type="submit" name="add_quest">
			</form>
		</div>
	</div>
	<script src='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js'></script>
	<script src='//code.jquery.com/jquery-1.11.2.min.js'></script>
	<script type="text/javascript">
		$(document).ready(function() {


			$(".sem-1").hide();
			$(".sem-2").hide();
			$(".sem-3").hide();
			$(".sem-4").hide();
			$(".sem-5").hide();
			$(".sem-6").hide();
			$(".sem-7").hide();
			$(".sem-8").hide();

			$("select.sem").change(function() {
				var selectedSem = $(".sem option:selected").val();
				var co = parseInt(selectedSem);


				for (i = 1; i <= 8; i++) {
					if (i == co) {
						$(".sem-" + co).show();
					} else {
						$(".sem-" + i).hide();
					}

				}



			});
		});

	</script>
</body>

</html>
