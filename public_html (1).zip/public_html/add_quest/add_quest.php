<?php 
ob_start();
session_start();
include("../includes/db.php");
include("../includes/function.php");

if(isset($_POST['add_quest'])){
	$branch1 = $branch = $_POST['branch'];
	$co1 = $co = $_POST['co'];
	$sem1 = $sem = $_POST['sem'];
	$sub = "sem-".$sem;
	$sub1 = $sub = $_POST[$sub];
	
	
		
		 $_SESSION['sem'] = $sem;
		 $_SESSION['sub'] = $sub;
		 $_SESSION['co'] = $co;
		 $_SESSION['branch'] = $branch;
	
	
		
}



if(isset($_POST['new_quest'])){
	
	
 	$sem =  $_SESSION['sem'] ;
	$sub = $_SESSION['sub'];
	$co = $_SESSION['co'];
	$branch = $_SESSION['branch'];
	
 	$quest = $_POST['quest'];

	
	$query = "INSERT INTO $branch (`sem`, `sub`, `quest`, `co`) VALUES ( '$sem', '$sub', '$quest', '$co');";
	$result = mysqli_query($conn,$query);
	
	query_check($result);
?>
	<div class="alert alert-success alert-dismissible fade show">
            <button class="close" data-dismiss="alert" type="button">
                <span>&times;</span>
            </button>
            	Question Added Successfully!!
        </div>
        <?php
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<title>Add Question</title>
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
</head>


<body>
	<div class="jumbotron">
		<h1 class="display-4 ">
			<p class="text-center">
				<span class="text-left">Branch:
					<?php echo $_SESSION['branch']."-".$_SESSION['sem']; ?></span>
				<span class="text-right">Subject:
					<?php echo  $_SESSION['sub'];?></span>
				<span class="text-right">CO:
					<?php echo  $_SESSION['co'];?></span>
			</p>

		</h1>
	</div>
	<div class="container">

		<form action="" method="post">
			<div class="row">
				<textarea name="quest" class="" id="quest" cols="30" rows="10">



			</textarea>
			</div>
			<br>

			<button name="new_quest" class="btn btn-danger">Add Question</button>
		</form>

	</div>
	<script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>
	<script>
		tinymce.init({
			selector: 'textarea'
		});

	</script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js"></script>
</body>

</html>
