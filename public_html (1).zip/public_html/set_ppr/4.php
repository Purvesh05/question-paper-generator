<?php 

ob_start();
session_start();
if(!empty($_POST['title1'])){
	 $title1 = $_POST['title1'];
	}else{
		$title1 = 'not entered';
	}


if(!empty($_POST['title2'])){
	 $title2 = $_POST['title2'];
	}else{
		$title2 = 'not entered';
	}
	
if(!empty($_POST['title3'])){
	 $title3 = $_POST['title3'];
	}else{
		$title3 = 'not entered';
	}



$qno1 = array();
$co1 = array();
$quest1 = array();
$mrk1 = array();
for( $i=1;$i<=5;$i++){
if(!empty($_POST['qno1-'.(string)  $i])){
		 $qno = array($_POST['qno1-'.(string) $i]);
		 $qno1 = array_merge($qno,$qno1);	
	}else{
		$qno = array("");
		$qno1 = array_merge($qno,$qno1);	
}
	
	if(!empty($_POST['co1-'.(string) $i])){
		$co = array($_POST['co1-'.(string) $i]);
		$co1 = array_merge($co,$co1);
	}else{
		$co = array("");
		$co1 = array_merge($co,$co1);
	}
	
	if(!empty($_POST['quest1-'.(string) $i])){
		$quest = array($_POST['quest1-'.(string) $i]); 
		$quest1 = array_merge($quest,$quest1);
	}else{
		$quest = array(""); 
		$quest1 = array_merge($quest,$quest1);
	}
	
	if(!empty($_POST['mrk1-'.(string) $i])){
		$mrk = array($_POST['mrk1-'.(string) $i]);
		$mrk1 = array_merge($mrk,$mrk1);
	}else{
		$mrk = array("");
		$mrk1 = array_merge($mrk,$mrk1);
	}
	
}





$qno2 = array();
$co2 = array();
$quest2 = array();
$mrk2 = array();
for( $i=1;$i<=2;$i++){
if(!empty($_POST['qno2-'.(string)  $i])){
		 $qno = array($_POST['qno2-'.(string) $i]);
		 $qno2 = array_merge($qno,$qno2);	
	}else{
		$qno = array("");
		$qno2 = array_merge($qno,$qno2);	
}
	
	if(!empty($_POST['co2-'.(string) $i])){
		$co = array($_POST['co2-'.(string) $i]);
		$co2 = array_merge($co,$co2);
	}else{
		$co = array("");
		$co2 = array_merge($co,$co2);
	}
	
	if(!empty($_POST['quest2-'.(string) $i])){
		$quest = array($_POST['quest2-'.(string) $i]); 
		$quest2 = array_merge($quest,$quest2);
	}else{
		$quest = array(""); 
		$quest2 = array_merge($quest,$quest1);
	}
	
	if(!empty($_POST['mrk2-'.(string) $i])){
		$mrk = array($_POST['mrk2-'.(string) $i]);
		$mrk2 = array_merge($mrk,$mrk2);
	}else{
		$mrk = array("");
		$mrk2 = array_merge($mrk,$mrk2);
	}
	
}

$qno3 = array();
$co3 = array();
$quest3 = array();
$mrk3 = array();
for( $i=1;$i<=2;$i++){
if(!empty($_POST['qno3-'.(string)  $i])){
		 $qno = array($_POST['qno3-'.(string) $i]);
		 $qno3 = array_merge($qno,$qno3);	
	}else{
		$qno = array("");
		$qno3 = array_merge($qno,$qno3);	
}
	
	if(!empty($_POST['co3-'.(string) $i])){
		$co = array($_POST['co3-'.(string) $i]);
		$co3 = array_merge($co,$co3);
	}else{
		$co = array("");
		$co3 = array_merge($co,$co3);
	}
	
	if(!empty($_POST['quest3-'.(string) $i])){
		$quest = array($_POST['quest3-'.(string) $i]); 
		$quest3 = array_merge($quest,$quest3);
	}else{
		$quest = array(""); 
		$quest3 = array_merge($quest,$quest3);
	}
	
	if(!empty($_POST['mrk3-'.(string) $i])){
		$mrk = array($_POST['mrk3-'.(string) $i]);
		$mrk3 = array_merge($mrk,$mrk3);
	}else{
		$mrk = array("");
		$mrk3 = array_merge($mrk,$mrk3);
	}
	
}s
/*array_reverse($qno1,true);
array_reverse($quest1);
array_reverse($mrk1);
array_reverse($co1);
print_r($qno1);
echo "<br>";
print_r($quest1);
echo "<br>";
print_r($mrk1);
echo "<br>";
print_r($co1);
echo "<br>";*/
?>







<!DOCTYPE html>
<html lang='en'>
<head>
	<meta charset='UTF-8'>
	<title>Document</title>
	<style>
	
		
		th{
			font-size: 1.1em;
		}
		th.qno{
			margin-right: 0;
			padding-left: 0;
		}
		th.quest{
			margin-left: 0;
			padding-left: 0;
		}
	</style>
</head>
<body>
<div id='HTMLtoPDF'>
<b>
	<h1 style='text-align: center'><b>F.C.R.I.T. Question paper manager</b></h1>
	<br>
	
	<div class="jumbotron">
		<h1 class="display-4 ">
			<p class="text-center">
				<span class="text-left">Branch:
					<?php echo  $_SESSION['branch']."-".$_SESSION['sem']; ?></span>
				<span class="text-right">Subject:
					<?php echo  $_SESSION['sub'];?></span>
					<span class="text-right">Date:
					<?php echo  $_SESSION['edate'];?></span>
					<span class="text-right">Papper:
					<?php echo  $_SESSION['etype'];?></span>
					<span class="text-right">Mark:
					<?php echo  $_SESSION['emrk'];?></span>
					<span class="text-right">Toal Time:
					<?php echo  $_SESSION['etime'];?></span>
					
				
			</p>

		</h1>
	</div>
	<h4 class="text-center"><?php echo $title1; ?></h4>
	
		
</b>



<table >

<?php 
	for($j=4;$j>=0;$j--){
		echo "<tr>";
		
		echo "<th class='qno'>$qno1[$j]&nbsp;&nbsp;&nbsp;</th>";
		echo "<th class='quest'>$quest1[$j] &nbsp;&nbsp;&nbsp;&nbsp;&nbsp</th>";
		echo "<th class='co'>$co1[$j]</th>";
		echo "<th class='mrk'>$mrk1[$j]&nbsp;&nbsp;&nbsp;</th>";
		
		echo "	</tr>";
	}
		?>


</table>
	
	
	<h4 class="text-center"><?php echo $title2; ?></h4>
	
	
	
<table >

<?php 
	for($j=1;$j>=0;$j--){
		echo "<tr>";
		
		echo "<th class='qno'>$qno2[$j]&nbsp;&nbsp;&nbsp;</th>";
		echo "<th class='quest'>$quest2[$j] &nbsp;&nbsp;&nbsp;&nbsp;&nbsp</th>";
		echo "<th class='co'>$co2[$j]</th>";
		echo "<th class='mrk'>$mrk2[$j]&nbsp;&nbsp;&nbsp;</th>";
		
		echo "	</tr>";
	}
		?>


</table>
	
	
	<h4 class="text-center"><?php echo $title2; ?></h4>
	
	
	
<table >

<?php 
	for($j=1;$j>=0;$j--){
		echo "<tr>";
		
		echo "<th class='qno'>$qno3[$j]&nbsp;&nbsp;&nbsp;</th>";
		echo "<th class='quest'>$quest3[$j] &nbsp;&nbsp;&nbsp;&nbsp;&nbsp</th>";
		echo "<th class='co'>$co3[$j]</th>";
		echo "<th class='mrk'>$mrk3[$j]&nbsp;&nbsp;&nbsp;</th>";
		
		echo "	</tr>";
	}
		?>


</table>
	
	
	

	</div>
	
	<button class="btn btn-primary" onclick='HTMLtoPDF()' >submit</button>
	
	<script src='../js/jspdf.js'></script>
	<script src='../js/jquery-2.1.3.js'></script>
	<script src='../js/pdfFromHTML.js'></script>
	<script>
	
		
	</script>
</body>
</html>



