<?php 

ob_start();
session_start();
if(!empty($_POST['title1'])){
	 $title1 = $_POST['title1'];
	}else{
		$title1 = 'not entered';
	}


if(!empty($_POST['title2'])){
	 $title2 = $_POST['title2'];
	}else{
		$title2 = 'not entered';
	}
	
if(!empty($_POST['title3'])){
	 $title3 = $_POST['title3'];
	}else{
		$title3 = 'not entered';
	}



$qno1 = array();
$co1 = array();
$quest1 = array();
$mrk1 = array();
for( $i=1;$i<=5;$i++){
if(!empty($_POST['qno1-'.(string)  $i])){
		 $qno = array($_POST['qno1-'.(string) $i]);
		 $qno1 = array_merge($qno,$qno1);	
	}else{
		$qno = array("");
		$qno1 = array_merge($qno,$qno1);	
}
	
	if(!empty($_POST['co1-'.(string) $i])){
		$co = array($_POST['co1-'.(string) $i]);
		$co1 = array_merge($co,$co1);
	}else{
		$co = array("");
		$co1 = array_merge($co,$co1);
	}
	
	if(!empty($_POST['quest1-'.(string) $i])){
		$quest = array($_POST['quest1-'.(string) $i]); 
		$quest1 = array_merge($quest,$quest1);
	}else{
		$quest = array(""); 
		$quest1 = array_merge($quest,$quest1);
	}
	
	if(!empty($_POST['mrk1-'.(string) $i])){
		$mrk = array($_POST['mrk1-'.(string) $i]);
		$mrk1 = array_merge($mrk,$mrk1);
	}else{
		$mrk = array("");
		$mrk1 = array_merge($mrk,$mrk1);
	}
	
}





$qno2 = array();
$co2 = array();
$quest2 = array();
$mrk2 = array();
for( $i=1;$i<=2;$i++){
if(!empty($_POST['qno2-'.(string)  $i])){
		 $qno = array($_POST['qno2-'.(string) $i]);
		 $qno2 = array_merge($qno,$qno2);	
	}else{
		$qno = array("");
		$qno2 = array_merge($qno,$qno2);	
}
	
	if(!empty($_POST['co2-'.(string) $i])){
		$co = array($_POST['co2-'.(string) $i]);
		$co2 = array_merge($co,$co2);
	}else{
		$co = array("");
		$co2 = array_merge($co,$co2);
	}
	
	if(!empty($_POST['quest2-'.(string) $i])){
		$quest = array($_POST['quest2-'.(string) $i]); 
		$quest2 = array_merge($quest,$quest2);
	}else{
		$quest = array(""); 
		$quest2 = array_merge($quest,$quest2);
	}
	
	if(!empty($_POST['mrk2-'.(string) $i])){
		$mrk = array($_POST['mrk2-'.(string) $i]);
		$mrk2 = array_merge($mrk,$mrk2);
	}else{
		$mrk = array("");
		$mrk2 = array_merge($mrk,$mrk2);
	}
	
}

$qno3 = array();
$co3 = array();
$quest3 = array();
$mrk3 = array();
for( $i=1;$i<=2;$i++){
if(!empty($_POST['qno3-'.(string)  $i])){
		 $qno = array($_POST['qno3-'.(string) $i]);
		 $qno3 = array_merge($qno,$qno3);	
	}else{
		$qno = array("");
		$qno3 = array_merge($qno,$qno3);	
}
	
	if(!empty($_POST['co3-'.(string) $i])){
		$co = array($_POST['co3-'.(string) $i]);
		$co3 = array_merge($co,$co3);
	}else{
		$co = array("");
		$co3 = array_merge($co,$co3);
	}
	
	if(!empty($_POST['quest3-'.(string) $i])){
		$quest = array($_POST['quest3-'.(string) $i]); 
		$quest3 = array_merge($quest,$quest3);
	}else{
		$quest = array(""); 
		$quest3 = array_merge($quest,$quest3);
	}
	
	if(!empty($_POST['mrk3-'.(string) $i])){
		$mrk = array($_POST['mrk3-'.(string) $i]);
		$mrk3 = array_merge($mrk,$mrk3);
	}else{
		$mrk = array("");
		$mrk3 = array_merge($mrk,$mrk3);
	}
	
}
/*array_reverse($qno1,true);
array_reverse($quest1);
array_reverse($mrk1);
array_reverse($co1);
print_r($qno1);
echo "<br>";
print_r($quest1);
echo "<br>";
print_r($mrk1);
echo "<br>";
print_r($co1);
echo "<br>";*/

print_r($quest2);
?>







<!DOCTYPE html>
<html lang='en'>

<head>

	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css'>
	<title>Document</title>
	<style>
		body {
			margin: 0;
			font-family: Arial, Helvetica, sans-serif;
			background-color: white;
		}

		.topnav {
			overflow: hidden;
			background-color: #141414;
		}

		.topnav a {
			float: left;
			display: block;
			color: white;
			text-align: center;
			padding: 14px 16px;
			text-decoration: none;
			font-size: 17px;
		}

		.topnav a:hover {
			background-color: rgba(239, 233, 233, 0.54);
			color: black;
		}

		.active {
			background-color: #4fea55;
			color: black;
		}

		.topnav .icon {
			display: none;
		}

		.logo {
			position: relative;
			left: 150px;
			top: -30px;
		}

		@media screen and (max-width: 600px) {
			.topnav a:not(:first-child) {
				display: none;
			}

			.topnav a.icon {
				float: right;
				display: block;
			}
		}

		@media screen and (max-width: 600px) {
			.topnav.responsive {
				position: relative;
			}

			.topnav.responsive .icon {
				position: absolute;
				right: 0;
				top: 0;
			}

			.topnav.responsive a {
				float: none;
				display: block;
				text-align: left;
			}
		}


		th {
			font-size: 1.1em;
		}

		th.qno {
			margin-right: 0;
			padding-left: 0;
		}

		th.quest {
			margin-left: 0;
			padding-left: 0;
		}

	</style>
</head>

<body>
	<div class="topnav" id="myTopnav">
		<a href="" class="active"><b>ELiT</b></a>
		<a href="../admin/index.php"><b>Dashboard</b></a>
		<a href="../admin/prev_ppr.php"><b>Previous papers</b></a>
		<a href="../admin/calendar.php"><b>Planner</b></a>
		<a href="../login/logout.php"><b>Logout</b></a>
		<a href="javascript:void(0);" class="icon" onclick="myFunction()">
			<i class="fa fa-bars"></i>
		</a>
	</div>
	<div id='printableArea'>
		<img src="logo.png" width="55px" style="position: relative; left: 520px;" alt="">
		<p style='text-align: center; font-family: "Times New Roman", Times, serif; font-size: 40px'><b>Fr. Conceicao Rodrigues Institute of Technology</b></p>
		<p style='text-align: center; font-family: "Times New Roman", Times, serif; font-size: 20px; position:relative; top:-30px;'><b>
				<?php echo $_SESSION['etype']; ?></b></p>
		<?php 
		$half = $_SESSION['edate'];
		$split = explode("/", $half);
		$day = $split[0];
		$month = $split[1];
		$year = $split[2];
		if($month >= "7" || $month <= "4"){
			echo "<p style='text-align: center; position: relative; top:-40px; font-family: 'Times New Roman', Times, serif;'><b>First half of " . $year . "</b></p>";
		}
		else{
			echo "<p style='text-align: center; position: relative; top:-40px; font-family: 'Times New Roman', Times, serif;'><b>Second half of " . $year . "</b></p>";
		}
	?>

		<p style='position: relative; top:-40px; left:60px; font-family: "Times New Roman", Times, serif;'><b>
				<?php echo "Subject: " .  $_SESSION['sub']; ?></b></p>


		<p style='position: relative; top:-80px; left:960px; font-family: "Times New Roman", Times, serif;'><b>
				<?php echo "Time: " .  $_SESSION['etime']; ?></b></p>


		<p style='position: relative; left: 60px; top: -90px; font-family: "Times New Roman", Times, serif;'><b>
				<?php echo "Branch: " .  $_SESSION['branch']."-".$_SESSION['sem']; ?></b></p>

		<p style='position: relative; left: 960px; top: -130px; font-family: "Times New Roman", Times, serif;'><b>
				<?php echo "Total marks: " .  $_SESSION['emrk']; ?></b></p>

		<br>
		<p style="position: relative; top: -120px; left: 40px;"><u>note</u>: Figures to the right indicate co number and marks respectively.</p>
		<div class="container">
			<p style='font-family: "Times New Roman", Times, serif; font-size: 20px; position: relative; top: -120px; left: 20px'><b>
					<?php echo "Q1. " . $title1; ?></b></p>
			<br>



			<table class="table" style="position: relative; top: -120px; left: 20px;">
				<?php 
	for($j=4;$j>=0;$j--){
	
		echo "<tr>";
		echo "<td class='qno'>$qno1[$j]&nbsp;&nbsp;&nbsp;</td>";
		echo "<td class='quest'>$quest1[$j] &nbsp;&nbsp;&nbsp;&nbsp;&nbsp</td>";
		echo "<td class='co' style='position: relative; top: 20px;'>$co1[$j]</td>";
		echo "<td class='mrk' style='position: relative; left: -50px; top: 20px;'>$mrk1[$j]&nbsp;&nbsp;&nbsp;</td>";
		echo"</tr>";
		
	}
		?>
			</table>



			<p style='font-family: "Times New Roman", Times, serif; font-size: 20px; position: relative; top: -120px; left: 20px'><b>
					<?php echo "Q2. " . $title2; ?></b></p>



			<table class="table" style="position: relative; top: -120px; left: 20px;">

				<?php 
	for($j=1;$j>=0;$j--){
		echo "<tr>";
		
		echo "<td class='qno'>$qno2[$j]&nbsp;&nbsp;&nbsp;</td>";
		echo "<td class='quest'>$quest2[$j] &nbsp;&nbsp;&nbsp;&nbsp;&nbsp</td>";
		echo "<td class='co'>$co2[$j]</td>";
		echo "<td class='mrk' style='position: relative; left: -50px;'>$mrk2[$j]&nbsp;&nbsp;&nbsp;</td>";
		
		echo "	</tr>";
	}
		?>


			</table>



			<p style='font-family: "Times New Roman", Times, serif; font-size: 20px; position: relative; top: -120px; left: 20px'><b>
					<?php echo "Q3. " . $title3; ?></b></p>



			<table class="table" style="position: relative; top: -120px; left: 20px;">

				<?php 
	for($j=1;$j>=0;$j--){
		echo "<tr>";
		
		echo "<td class='qno'>$qno3[$j]&nbsp;&nbsp;&nbsp;</td>";
		echo "<td class='quest'>$quest3[$j] &nbsp;&nbsp;&nbsp;&nbsp;&nbsp</td>";
		echo "<td class='co'>$co3[$j]</td>";
		echo "<td class='mrk' style='position: relative; left: -50px;'>$mrk3[$j]&nbsp;&nbsp;&nbsp;</td>";
		
		echo "	</tr>";
	}
		?>


			</table>

			<p style="text-align: center">---------------------------------------------------------------all the best!-------------------------------------------------------------------</p>

		</div>
	</div>
	<br>
	<br>
	<br>
	<br>

	<button class="btn btn-primary" onclick="printDiv('printableArea')" style="position: relative; left: 800px">submit</button>
	<br>
	<br>
	<br>
	<script>
		function printDiv(divName) {
			var printContents = document.getElementById(divName).innerHTML;
			var originalContents = document.body.innerHTML;

			document.body.innerHTML = printContents;

			window.print();

			document.body.innerHTML = originalContents;
		}

	</script>

	<script src='../js/jspdf.js'></script>
	<script src='../js/jquery-2.1.3.js'></script>
	<script src='../js/pdfFromHTML.js'></script>
	<script>


	</script>
</body>

</html>
