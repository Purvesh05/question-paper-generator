<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css'>
</head>

<body>
	<div class="container">
		<div class="row">

			<h4 style="text-align: center">Select Branch,Semester,Subject and Exam type for filling the Question Paper</h4>
			<br>
		</div>

		<form action="1.php" method="post">
			<div class="row">
				<div class="col-sm-3">
					<label for="">Branch: </label>
					<select name="branch" class="form-control" id="">
						<option value="Not Entered">--</option>
						<option value="it">IT</option>
						<option value="comps">COMPS</option>
						<option value="mech">MECH</option>
						<option value="elec">ELEC</option>
						<option value="extc">EXTC</option>
					</select>
				</div>
				<div class="col-sm-3">
					<label for="">Semester</label>
					<select class="sem form-control" name="sem">
						<option value="Not Entered">--</option>
						<option value="1">SEM-1</option>
						<option value="2">SEM-2<option>
						<option value="3">SEM-3</option>
						<option value="4">SEM-4</option>
						<option value="5">SEM-5</option>
						<option value="6">SEM-6</option>
						<option value="7">SEM-7</option>
						<option value="8">SEM-8</option>
					</select><br><br>
				</div>
				<div class="col-sm-3">
					<label for="Subject">Subject:</label>



					<select class="sem-1 form-control" name="sem-1">
						<label>Sem-1</label>
						<option value="Not Entered">--</option>
						<option value="1">Sem-1 sub1 </option>
						<option value="2">Sem-1 sub2</option>
						<option value="3">Sem-1 sub3</option>
					</select>


					<select class="sem-2 form-control" name="sem-2">
						<label>Sem-2</label>
						<option value="Not Entered">--</option>
						<option value="1">Sem-2 sub1 </option>
						<option value="2">Sem-2 sub2</option>
						<option value="3">Sem-2 sub3</option>
					</select>

					<select class="sem-3 form-control " name="sem-3">
						<label>Sem-3</label>
						<option value="Not Entered">--</option>
						<option value="1">Sem-3 sub1 </option>
						<option value="2">Sem-3 sub2</option>
						<option value="3">Sem-3 sub3</option>
					</select>

					<select class="sem-4 form-control" name="sem-4">
						<label>Sem-4</label>
						<option value="Not Entered">--</option>
						<option value="1">Sem-4 sub1 </option>
						<option value="2">Sem-4 sub2</option>
						<option value="3">Sem-4 sub3</option>
					</select>
					<select class="sem-5 form-control" name="sem-5">
						<label>Sem-5</label>
						<option value="Not Entered">--</option>
						<option value="CNS">CNS</option>
						<option value="MEP">MEP</option>

					</select>
					<select class="sem-6 form-control" name="sem-6">
						<label>Sem-6</label>
						<option value="Not Entered">--</option>
						<option value="1">Sem-6 sub1 </option>
						<option value="2">Sem-6 sub2</option>
						<option value="3">Sem-6 sub3</option>
					</select>
					<select class="sem-7 form-control" name="sem-7">
						<label>Sem-7</label>
						<option value="Not Entered">--</option>
						<option value="1">Sem-7 sub1 </option>
						<option value="2">Sem-7 sub2</option>
						<option value="3">Sem-8 sub3</option>
					</select>
					<select class="sem-8 form-control" name="sem-8">
						<label>Sem-8</label>
						<option value="Not Entered">--</option>
						<option value="1">Sem-8 sub1 </option>
						<option value="2">Sem-8 sub2</option>
						<option value="3">Sem-8 sub3</option>
					</select>
				</div>

				<div class="col-sm-3">
					<label for="">Exam date: </label>
					<input class="form-control" type="date" name="edate">
				</div>
				<br>
				<div class="col-sm-4">
					<label for="">Exam Type</label>
					<select name="etype" class="form-control" id="etype">
						<option value="Unit-1">Unit-1</option>
						<option value="Unit-2">Unit-2</option>
						<option value="Prelims">Prelims</option>				
					</select>
				</div>
				<div class="col-sm-4">
					<label for="">Max Marks</label>
					<select  class="form-control" name="emrk" id="emrk">
						<option value="80">80</option>
						<option value="20">20</option>				
					</select>
				</div>
				<div class="col-sm-4">
					<label for="">Total Time</label>
					<select  class="form-control" name="etime" id="etime">
						<option value="1 Hr">1 Hr</option>
						<option value="3 Hr">3 Hr</option>				
					</select>
				</div>

<br><br>
<br><br>
<br><br>
			<div class="col-sm-4"></div>
			<div class="col-sm-4">
				<input class="btn btn-success" type="submit" name="add_quest">
			</div>
				

			</div>
		</form>
	</div>
	<script src='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js'></script>
	<script src='//code.jquery.com/jquery-1.11.2.min.js'></script>
	<script type="text/javascript">
		$(document).ready(function() {


			$(".sem-1").hide();
			$(".sem-2").hide();
			$(".sem-3").hide();
			$(".sem-4").hide();
			$(".sem-5").hide();
			$(".sem-6").hide();
			$(".sem-7").hide();
			$(".sem-8").hide();

			$("select.sem").change(function() {
				var selectedSem = $(".sem option:selected").val();
				var co = parseInt(selectedSem);


				for (i = 1; i <= 8; i++) {
					if (i == co) {
						$(".sem-" + co).show();
					} else {
						$(".sem-" + i).hide();
					}

				}



			});
		});

	</script>
</body>

</html>
