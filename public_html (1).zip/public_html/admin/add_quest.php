<?php session_start();
if(!isset($_SESSION['userId']))
{
    // not logged in
    header('Location: ../login/alogin.php');
    exit();
}
include "includes/add_quest.php"; 

?>
<html lang="en">

<head>
  <!-- Required meta tags-->
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="au theme template">
  <meta name="author" content="Hau Nguyen">
  <meta name="keywords" content="au theme template">

  <!-- Title Page-->
  <title>QBank</title>

<?php include "link.php"; ?>
  <!-- Main CSS-->
  <link href="css/theme.css" rel="stylesheet" media="all">

</head>

<body class="animsition">
  <div class="page-wrapper">
    <!-- HEADER MOBILE-->
    <header class="header-mobile d-block d-lg-none">
      <div class="header-mobile__bar">
        <div class="container-fluid">
          <div class="header-mobile-inner">
            <a class="logo" href="index.html">
              <img src="images/icon/logo.png" alt="CoolAdmin" />
            </a>
            <button class="hamburger hamburger--slider" type="button">
              <span class="hamburger-box">
                <span class="hamburger-inner"></span>
              </span>
            </button>
          </div>
        </div>
      </div>
      <nav class="navbar-mobile">
        <div class="container-fluid">
          <ul class="navbar-mobile__list list-unstyled">
            <li class="has-sub">
              <a class="js-arrow" href="index.php">
                <i class="fas fa-tachometer-alt"></i>Dashboard</a>
            </li>
            <li>
              <a href="quest_ppr.php">
                <i class="fas fa-chart-bar"></i>Question Paper</a>
            </li>
          </ul>
        </div>
      </nav>
    </header>
    <!-- END HEADER MOBILE-->

    <!-- MENU SIDEBAR-->
    <aside class="menu-sidebar d-none d-lg-block">
      <div class="logo">
        <a href="#">
          <img src="images/icon/logo.png" alt="Cool Admin" />
        </a>
      </div>
      <div class="menu-sidebar__content js-scrollbar1">
        <nav class="navbar-sidebar">
          <ul class="list-unstyled navbar__list">
            <li class="has-sub">
              <a class="js-arrow" href="index.php">
                <i class="fas fa-tachometer-alt"></i>Dashboard</a>
            </li>
            <li class="active has-sub">
              <a href="quest_ppr.php">
                <i class="fas fa-chart-bar"></i>Questiion Paper</a>
            </li>
          </ul>
        </nav>
      </div>
    </aside>
    <!-- END MENU SIDEBAR-->

    <!-- PAGE CONTAINER-->
    <div class="page-container">
      <!-- HEADER DESKTOP-->
      <header class="header-desktop">
        <div class="section__content section__content--p30">
          <div class="container-fluid">
            <div class="header-wrap">
             <br>
             <br>
             <br>
             <br>
             <br>
             <br>
              <div class="header-button">
                <div class="noti-wrap">
                </div>
                <div class="account-wrap">
                  <div class="account-item clearfix js-item-menu">
                    <div class="image">
                    <?php echo "<img src='images/" . $_SESSION['uimage'] . "' />" ?>
                    </div>
                    <div class="content">
                      <a class="js-acc-btn" href="#"><?php echo $_SESSION['firstname']; ?></a>
                    </div>
                    <div class="account-dropdown js-dropdown">
                      <div class="info clearfix">
                        <div class="image">
                          <a href="#">
                          <?php echo "<img src='images/" . $_SESSION['uimage'] . "' />" ?>
                          </a>
                        </div>
                        <div class="content">
                          <h5 class="name">
                            <a href="#"><?php echo $_SESSION['firstname'] . " " . $_SESSION['lastname']; ?></a>
                          </h5>
                          <span class="email"><?php echo $_SESSION['user_email']; ?></span>
                        </div>
                      </div>
                      <div class="account-dropdown__footer">
                        <a href="../login/logout.php">
                          <i class="zmdi zmdi-power"></i>Logout</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>
      <!-- END HEADER DESKTOP-->

      <!-- MAIN CONTENT-->
      <div class="main-content">
        <div class="section__content section__content--p30">
           <div class="container">
            <form action="" method="post">
                <h3 style="text-align: center">Fill the form to add question to the repository</h3>
                <br>
                <br>
                <label for="">branch: </label>
                <select name="branch" id="">
                    <option value="">--</option>
                    <option value="it">IT</option>
                    <option value="comps">COMPS</option>
                    <option value="mech">MECH</option>
                    <option value="elec">ELEC</option>
                    <option value="extc">EXTC</option>
                </select>
                <label for="">   semester: </label>
                <select name="sem" id="">
                    <option value="">--</option>
                    <option value="1">sem 1</option>
                    <option value="2">sem 2</option>
                    <option value="3">sem 3</option>
                    <option value="4">sem 4</option>
                    <option value="5">sem 5</option>
                    <option value="6">sem 6</option>
                    <option value="7">sem 7</option>
                    <option value="8">sem 8</option>
                </select>
                <br>
                <br>
                <label for="">Subject: </label>
                <input type="text" name="subject">
                <br>
                <br>
                <label for="">Add questions:</label>
                <input type="text" name="quest">
                <label for="">Chapter: </label>
                <input type="text" name="chap">
                <br>
                <br>
                <label for="">Image (if required): </label>
                <input type="file" name="qimg">
                <br><br>
                <label for="">Marks: </label>
                <input type="text" name="marks">
                <br><br>
                <input class="btn btn-success" type="submit" name="add_quest">
            </form>
            </div>
        </div>
      </div>
      <section>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="copyright">
                                <p>Copyright © 2018 ELIT. All rights reserved.<br> Made with love by <a href="https://www.namanlazarus02.wixsite.com/elit">ELIT</a>.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
    </div>
    <!-- END PAGE CONTAINER-->

  </div>

  <!-- Jquery JS-->
  <script src="vendor/jquery-3.2.1.min.js"></script>
<?php include "script.php"; ?>
  <!-- Main JS-->
  <script src="js/main.js"></script>

</body>

</html>
<!-- end document-->