<html>
<head>
	<title>QBank</title>
	<?php include "includes/link3.php"; ?>
	
</head>
<body>
<br>
<h1 style="text-align: center">Previous years question papers</h1><br><br>
<div class="container">
	<div class="panel-group" id="accordion">
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">
        Sem 3</a>
      </h4>
    </div>
    <div id="collapse1" class="panel-collapse collapse">
      <div class="panel-body">Lorem ipsum dolor sit amet, consectetur adipisicing elit,
      sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
      minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
      commodo consequat.</div>
    </div>
  </div>
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">
        Sem 4</a>
      </h4>
    </div>
    <div id="collapse2" class="panel-collapse collapse">
      <div class="panel-body">
      	<table>
      		<tr>
      			<th></th>
      		</tr>
      	</table>
      </div>
    </div>
  </div>
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapse3">
        Sem 5</a>
      </h4>
    </div>
    <div id="collapse3" class="panel-collapse collapse">
      <div class="panel-body">
      	<table class="table">
      		<tr>
      			<th style="text-align: center">Computer Graphics and VR</th>
      		</tr>
      		<tr>
				<td><a href="pprs/may18.pdf" download>May 2018</a></td>
				<td><a href="pprs/dec17.pdf" download>Dec 2017</a></td>
				<td><a href="pprs/may17.pdf" download>May 2017</a></td>
				<td><a href="pprs/dec16.pdf" download>Dec 2016</a></td>
				<td><a href="pprs/may16.pdf" download>May 2016</a></td>
				<td><a href="pprs/dec15.pdf" download>Dec 2015</a></td>
				<td><a href="pprs/may15.pdf" download>May 2015</a></td>
				<td><a href="pprs/dec14.pdf" download>Dec 2014</a></td>
      		</tr>
      		
      		<tr>
      			<th style="text-align: center">Operating systems</th>
      		</tr>
      		<tr>
				<td><a href="pprs/may18.pdf" download>May 2018</a></td>
				<td><a href="pprs/dec17.pdf" download>Dec 2017</a></td>
				<td><a href="pprs/may17.pdf" download>May 2017</a></td>
				<td><a href="pprs/dec16.pdf" download>Dec 2016</a></td>
				<td><a href="pprs/may16.pdf" download>May 2016</a></td>
				<td><a href="pprs/dec15.pdf" download>Dec 2015</a></td>
				<td><a href="pprs/may15.pdf" download>May 2015</a></td>
				<td><a href="pprs/dec14.pdf" download>Dec 2014</a></td>
      		</tr>
      		
      		<tr>
      			<th style="text-align: center">Microcontroller and embedded programming</th>
      		</tr>
      		<tr>
				<td><a href="pprs/may18.pdf" download>May 2018</a></td>
				<td><a href="pprs/dec17.pdf" download>Dec 2017</a></td>
				<td><a href="pprs/may17.pdf" download>May 2017</a></td>
				<td><a href="pprs/dec16.pdf" download>Dec 2016</a></td>
				<td><a href="pprs/may16.pdf" download>May 2016</a></td>
				<td><a href="pprs/dec15.pdf" download>Dec 2015</a></td>
				<td><a href="pprs/may15.pdf" download>May 2015</a></td>
				<td><a href="pprs/dec14.pdf" download>Dec 2014</a></td>
      		</tr>
      		
      		<tr>
      			<th style="text-align: center">Internet Programming</th>
      		</tr>
      		<tr>
				<td><a href="pprs/may18.pdf" download>May 2018</a></td>
				<td><a href="pprs/dec17.pdf" download>Dec 2017</a></td>
				<td><a href="pprs/may17.pdf" download>May 2017</a></td>
				<td><a href="pprs/dec16.pdf" download>Dec 2016</a></td>
				<td><a href="pprs/may16.pdf" download>May 2016</a></td>
				<td><a href="pprs/dec15.pdf" download>Dec 2015</a></td>
				<td><a href="pprs/may15.pdf" download>May 2015</a></td>
				<td><a href="pprs/dec14.pdf" download>Dec 2014</a></td>
      		</tr>
      		
      		<tr>
      			<th style="text-align: center">Advanced database management systems</th>
      		</tr>
      		<tr>
				<td><a href="pprs/may18.pdf" download>May 2018</a></td>
				<td><a href="pprs/dec17.pdf" download>Dec 2017</a></td>
				<td><a href="pprs/may17.pdf" download>May 2017</a></td>
				<td><a href="pprs/dec16.pdf" download>Dec 2016</a></td>
				<td><a href="pprs/may16.pdf" download>May 2016</a></td>
				<td><a href="pprs/dec15.pdf" download>Dec 2015</a></td>
				<td><a href="pprs/may15.pdf" download>May 2015</a></td>
				<td><a href="pprs/dec14.pdf" download>Dec 2014</a></td>
      		</tr>
      	</table>
      </div>
    </div>
  </div>
  
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">
        Sem 6</a>
      </h4>
    </div>
    <div id="collapse1" class="panel-collapse collapse">
      <div class="panel-body">Lorem ipsum dolor sit amet, consectetur adipisicing elit,
      sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
      minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
      commodo consequat.</div>
    </div>
  </div>
  
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">
        Sem 7</a>
      </h4>
    </div>
    <div id="collapse1" class="panel-collapse collapse">
      <div class="panel-body">Lorem ipsum dolor sit amet, consectetur adipisicing elit,
      sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
      minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
      commodo consequat.</div>
    </div>
  </div>
  
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">
        Sem 8</a>
      </h4>
    </div>
    <div id="collapse1" class="panel-collapse collapse">
      <div class="panel-body">Lorem ipsum dolor sit amet, consectetur adipisicing elit,
      sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
      minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
      commodo consequat.</div>
    </div>
  </div>
  
</div>
	</div>
</body>
</html>