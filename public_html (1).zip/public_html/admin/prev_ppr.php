<html>
	<head>
		<title>QBank</title>
		<?php include "includes/link3.php"; ?>
		
	<style>
        body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;

}

.topnav {
  overflow: hidden;
  background-color: #141414;
}

.topnav a {
  float: left;
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: rgba(239, 233, 233, 0.54);
  color: black;
}

.active {
  background-color: #4fea55;
  color: black;
}

.topnav .icon {
  display: none;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child) {display: none;}
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
}
    .box{
    padding:60px 0px;
}

.box-part{
    background:rgba(167, 205, 250, 0.65);
    border-radius:10px;
    padding:60px 10px;
    margin:30px 0px;
}

.box-part:hover{
    background:#4183D7;
}

.box-part:hover .fa , 
.box-part:hover .title , 
.box-part:hover .text ,
.box-part:hover a{
    color:#FFF;
    -webkit-transition: all 1s ease-out;
    -moz-transition: all 1s ease-out;
    -o-transition: all 1s ease-out;
    transition: all 1s ease-out;
}

.text{
    margin:20px 0px;
}

.fa{
     color:#4183D7;
}
    </style>
	</head>
	<body>
<div class="topnav" id="myTopnav">
	<a href="" class="active"><b>ELiT</b></a>
	<a href="../admin/index.php"><b>Dashboard</b></a>
	<a href="../admin/prev_ppr.php"><b>Previous papers</b></a>
	<a href="../admin/calendar.php"><b>Planner</b></a>
	<a href="../login/logout.php" style="align: end"><b>Logout</b></a>
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
</div>
	<h1 style="text-align: center">Select the branch</h1>
		<div class="row">
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
				<p>   </p>
			</div>
			    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
               
					<div class="box-part text-center">
                        
						<div class="title">
							<h3>Humanities</h3>
						</div>
                        
                        
						<a href="">see papers</a>
                        
					 </div>
				</div>	
		</div>
		
		<div class="row">
			<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
				<p>   </p>
			</div>
			    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
               
					<div class="box-part text-center">
                        
						<div class="title">
							<h3>Information Technology</h3>
						</div>
                        
                        
						<a href="it.php">see papers</a>
                        
					 </div>
				</div>	
				<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
               
					<div class="box-part text-center">
                        
						<div class="title">
							<h3>Computer Engineering</h3>
						</div>
                        
                        
						<a href="">see paper</a>
                        
					 </div>
				</div>	
		</div>
		
		<div class="row">
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
				
					<div class="box-part text-center">
                        
						<div class="title">
							<h3>Mechanical</h3>
						</div>
                        
                        
						<a href="">see paper</a>
                        
					 </div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
				
					<div class="box-part text-center">
                        
						<div class="title">
							<h3>Electrical</h3>
						</div>
                        
                        
						<a href="">see paper</a>
                        
					 </div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
				
					<div class="box-part text-center">
                        
						<div class="title">
							<h3>Electronics & Telecommunications</h3>
						</div>
                        
                        
						<a href="">see paper</a>
                        
					 </div>
			</div>
		</div>
	</body>
</html>