<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>ELIT</title>
  
  
  
      <link rel="stylesheet" href="css/style.css">

</head>

<body>

  <div class='container'>
  <section class='card'>
    <div class='card_inner'>
      <div class='card_inner__circle'>
        <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/cog.png'>
      </div>
      <div class='card_inner__header'>
        <img src='http://4vector.com/i/free-vector-modern-city_093317_bluecity.jpg'>
      </div>
      <div class='card_inner__content'>
        <div class='title'></div>
        <div class='price'>Teacher's Login</div>
        <div class='text'>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur at posuere eros. Interdum et malesuada fames ac ante ipsum primis in faucibus. <br/> <br/>Fusce sed tortor in orci ultrices tempor quis ut leo. Fusce imperdiet eget ante eu faucibus. Nam rhoncus sapien</div>
      </div>
      <div class='card_inner__cta'>
        <button>
          <span>
            <a href="../login/alogin.php">Click Here</a>
          </span>
        </button>
      </div>
    </div>
  </section>
  <section class='card'>
    <div class='card_inner'>
      <div class='card_inner__circle'>
        <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/paperplane.png'>
      </div>
      <div class='card_inner__header'>
        <img src='http://7428.net/wp-content/uploads/2013/06/Forest-Creek.jpg'>
      </div>
      <div class='card_inner__content'>
        <div class='title'></div>
        <div class='price'>Student's Login</div>
        <div class='text'>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur at posuere eros. Interdum et malesuada fames ac ante ipsum primis in faucibus. <br/> <br/>Fusce sed tortor in orci ultrices tempor quis ut leo. Fusce imperdiet eget ante eu faucibus. Nam rhoncus sapien</div>
      </div>
      <div class='card_inner__cta'>
        <button>
            <span><a href="../login/slogin.php">Click Here</a></span>
        </button>
      </div>
    </div>
  </section>
</div>
  
  

</body>

</html>
