<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>ELIT</title>
  
  
  
      <link rel="stylesheet" href="css/style.css">

</head>

<body>

  <div class='container'>
  <section class='card'>
    <div class='card_inner'>
      <div class='card_inner__circle'>
        <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/rocket.png'>
      </div>
      <div class='card_inner__header'>
        <img src='http://www.pixeden.com/media/k2/galleries/343/002-city-vector-background-town-vol2.jpg'>
      </div>
      <div class='card_inner__content'>
        <div class='title'>For creating the paper</div>
        <div class='price'>Paper generator</div>
        <div class='text'>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur at posuere eros. Interdum et malesuada fames ac ante ipsum primis in faucibus. <br/> <br/>Fusce sed tortor in orci ultrices tempor quis ut leo. Fusce imperdiet eget ante eu faucibus. Nam rhoncus sapien</div>
      </div>
      <div class='card_inner__cta'>
        <button>
          <span>Click Here</span>
        </button>
      </div>
    </div>
  </section>
  <section class='card'>
    <div class='card_inner'>
      <div class='card_inner__circle'>
        <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/cog.png'>
      </div>
      <div class='card_inner__header'>
        <img src='http://4vector.com/i/free-vector-modern-city_093317_bluecity.jpg'>
      </div>
      <div class='card_inner__content'>
        <div class='title'>For adding new questions</div>
        <div class='price'>Question adder</div>
        <div class='text'>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur at posuere eros. Interdum et malesuada fames ac ante ipsum primis in faucibus. <br/> <br/>Fusce sed tortor in orci ultrices tempor quis ut leo. Fusce imperdiet eget ante eu faucibus. Nam rhoncus sapien</div>
      </div>
      <div class='card_inner__cta'>
        <button>
          <span>
            <a href='https://www.codepen.io/jcoulterdesign' target='_blank'>Click Here</a>
          </span>
        </button>
      </div>
    </div>
  </section>
  <section class='card'>
    <div class='card_inner'>
      <div class='card_inner__circle'>
        <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/paperplane.png'>
      </div>
      <div class='card_inner__header'>
        <img src='http://7428.net/wp-content/uploads/2013/06/Forest-Creek.jpg'>
      </div>
      <div class='card_inner__content'>
        <div class='title'>To learn more about this</div>
        <div class='price'>Instruction manual</div>
        <div class='text'>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur at posuere eros. Interdum et malesuada fames ac ante ipsum primis in faucibus. <br/> <br/>Fusce sed tortor in orci ultrices tempor quis ut leo. Fusce imperdiet eget ante eu faucibus. Nam rhoncus sapien</div>
      </div>
      <div class='card_inner__cta'>
        <button>
          <span>Click Here</span>
        </button>
      </div>
    </div>
  </section>
</div>
  
  

</body>

</html>
