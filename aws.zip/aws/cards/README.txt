A Pen created at CodePen.io. You can find this one at https://codepen.io/jcoulterdesign/pen/NxMoja.

 Jumping on the glowing buttons and box shadow band wagon with this one