<?php 
ob_start();
session_start();
include("../includes/db.php");
include("../includes/function.php");

if(isset($_POST['add_quest'])){
	$branch1 = $branch = $_POST['branch'];
	$co1 = $co = $_POST['co'];
	$sem1 = $sem = $_POST['sem'];
	$sub = "sem-".$sem;
	$sub1 = $sub = $_POST[$sub];
	
	
		
		 $_SESSION['sem'] = $sem;
		 $_SESSION['sub'] = $sub;
		 $_SESSION['co'] = $co;
		 $_SESSION['branch'] = $branch;
	
	
		
}



if(isset($_POST['new_quest'])){
	
	
 	$sem =  $_SESSION['sem'] ;
	$sub = $_SESSION['sub'];
	$co = $_SESSION['co'];
	$branch = $_SESSION['branch'];
	
 	$quest = $_POST['quest'];

	
	$query = "INSERT INTO $branch (`sem`, `sub`, `quest`, `co`) VALUES ( '$sem', '$sub', '$quest', '$co');";
	$result = mysqli_query($conn,$query);
	
	query_check($result);
?>
	<div class="alert alert-success alert-dismissible fade show">
            <button class="close" data-dismiss="alert" type="button">
                <span>&times;</span>
            </button>
            	Question Added Successfully!!
        </div>
        <?php
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<title>QBank</title>
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
	
}

.topnav {
  overflow: hidden;
  background-color: #141414;
}

.topnav a {
  float: left;
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: rgba(239, 233, 233, 0.54);
  color: black;
}

.active {
  background-color: #4fea55;
  color: black;
}

.topnav .icon {
  display: none;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child) {display: none;}
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
}
</style>
</head>


<body>
<div class="topnav" id="myTopnav">
	<a href="" class="active"><b>ELiT</b></a>
	<a href="../admin/index.php"><b>Dashboard</b></a>
	<a href="../admin/prev_ppr.php"><b>Previous papers</b></a>
	<a href="../admin/calendar.php"><b>Planner</b></a>
	<a href="../admin/search.php"><b>Google</b></a>
	<a href="../login/logout.php" style="align: end"><b>Logout</b></a>
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
</div>


	<div class="jumbotron">
		<h1 class="display-4 ">
			<p class="text-center">
				<span class="text-left">Branch:
					<?php echo $_SESSION['branch']."-".$_SESSION['sem']; ?></span>
				<span class="text-right">Subject:
					<?php echo  $_SESSION['sub'];?></span>
				<span class="text-right">CO:
					<?php echo  $_SESSION['co'];?></span>
			</p>

		</h1>
	</div>
	<div class="container">

		<form action="" method="post">
			<div class="row">
				<textarea name="quest" class="" id="quest" cols="30" rows="10">



			</textarea>
			</div>
			<br>

			<button name="new_quest" class="btn btn-danger">Add Question</button>
		</form>

	</div>
	<script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>
	<script>
		tinymce.init({
			selector: 'textarea'
		});

	</script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js"></script>
</body>

</html>
