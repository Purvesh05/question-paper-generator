<html>
    <head>
        
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">

    <!-- Title Page-->
    <title>QBank</title>

 <?php include "includes/links.php"; ?>
    <!-- Favicon -->
    <link rel="icon" type="image/png" sizes="32x32" href="../img/bg-img/favicon-32x32.png">

    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">
    <style>
        body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;

}

.topnav {
  overflow: hidden;
  background-color: #141414;
}

.topnav a {
  float: left;
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: rgba(239, 233, 233, 0.54);
  color: black;
}

.active {
  background-color: #4fea55;
  color: black;
}

.topnav .icon {
  display: none;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child) {display: none;}
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
}
        </style>
    </head>
    <body>
<div class="topnav" id="myTopnav">
	<a href="" class="active"><b>ELiT</b></a>
	<a href="../admin/index.php"><b>Dashboard</b></a>
	<a href="../admin/prev_ppr.php"><b>Previous papers</b></a>
	<a href="../admin/calendar.php"><b>Planner</b></a>
	<a href="../login/logout.php" style="align: end"><b>Logout</b></a>
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
</div><br>
        <div class="row">
            <div class="col-md-12">
                <h1 style="text-align:center">QBank academic planner</h1>
            </div>
        </div><br><br>
        <div class="row">
            <div class="col-lg-3">
                <p>     </p>
            </div>
            <div class="col-lg-6">
                <iframe src="https://calendar.google.com/calendar/embed?height=600&amp;wkst=2&amp;bgcolor=%23ffffcc&amp;src=6kqksodvj98u6o4clhf17o8eas%40group.calendar.google.com&amp;color=%238D6F47&amp;ctz=Asia%2FCalcutta" style="border:solid 1px #777" width="800" height="600" frameborder="0" scrolling="no"></iframe>
            </div>
            <div class="col-lg-3">
                <p>    </p>
            </div>
        </div>
    </body>
</html>