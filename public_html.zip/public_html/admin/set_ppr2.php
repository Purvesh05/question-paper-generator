<?php session_start();
if(!isset($_SESSION['userId']))
{
    // not logged in
    header('Location: ../login/alogin.php');
    exit();
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">

    <!-- Title Page-->
    <title>QBank</title>

<?php include "link.php"; ?>
    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">
    <script>
        function openInNewTab(url) {
  var win = window.open(url, '_blank');
  win.focus();
}
    </script>
    
    <?php include "../includes/link.php"; ?>

</head>

<body class="animsition">
    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
        <header class="header-mobile d-block d-lg-none">
            <div class="header-mobile__bar">
                <div class="container-fluid">
                    <div class="header-mobile-inner">
                        <a class="logo" href="index.html">
                            <img src="images/icon/logo.png" alt="CoolAdmin" />
                        </a>
                        <button class="hamburger hamburger--slider" type="button">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <nav class="navbar-mobile">
                <div class="container-fluid">
                    <ul class="navbar-mobile__list list-unstyled">
                        <li class="has-sub">
                            <a class="js-arrow" href="index.php">
                                <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                        </li>
                        <li>
                            <a href="chart.html">
                                <i class="fas fa-chart-bar"></i>Question Paper</a>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>
        <!-- END HEADER MOBILE-->

        <!-- MENU SIDEBAR-->
        <aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
                <a href="#">
                    <img src="images/icon/logo.png" alt="Cool Admin" />
                </a>
            </div>
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li class="has-sub">
                            <a class="js-arrow" href="index.php">
                                <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                        </li>
                        <li>
                            <a href="set_ppr.php">
                                <i class="fas fa-chart-bar"></i>Question Paper</a>
                        </li>
                    </ul>
                </nav>
            </div>
        </aside>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <header class="header-desktop">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="header-wrap">
                           <br>
                           <br>
                           <br>
                           <br>
                           <br>
                           <br>
                            <div class="header-button">
                                <div class="noti-wrap">
                                </div>
                                <div class="account-wrap">
                                    <div class="account-item clearfix js-item-menu">
                                        <div class="image">
                                        <?php echo "<img src='images/" . $_SESSION['uimage'] . "' />" ?>
                                        </div>
                                        <div class="content">
                                            <a class="js-acc-btn" href="#"><?php echo $_SESSION['firstname']; ?></a>
                                        </div>
                                        <div class="account-dropdown js-dropdown">
                                            <div class="info clearfix">
                                                <div class="image">
                                                    <a href="#">
                                                    <?php echo "<img src='images/" . $_SESSION['uimage'] . "' />" ?>
                                                    </a>
                                                </div>
                                                <div class="content">
                                                    <h5 class="name">
                                                        <a href="#"><?php echo $_SESSION['firstname'] . " " . $_SESSION['lastname']; ?></a>
                                                    </h5>
                                                    <span class="email"><?php echo $_SESSION['user_email']; ?></span>
                                                </div>
                                            </div>
                                            <div class="account-dropdown__footer">
                                                <a href="../login/logout.php">
                                                    <i class="zmdi zmdi-power"></i>Logout</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <!-- END HEADER DESKTOP-->

            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
               
                 <div class="row">
                     <div class="col-sm-12">
                         <h1 style="text-align: center"><b>F.C.R.I.T. Question paper manager</b></h1>
                         <br>
                         <br>
                     </div>
                 </div>
                  <div class="row">
                  <div class="col-sm-4">
                   <label for="">exam date: </label>
                    <input class="form-control" type="date"  name="edate">
                    </div>
                    <div class="col-sm-4">
                        <label for="">Duration: </label>
                        <input class="form-control" type="text" name="etime">
                    </div>
                    <div class="col-sm-4">
                        <label for="">Subject: </label>
                        <input class="form-control" type="text" name="esub">
                    </div>
                    </div>
                    
                    <!-- paper entry -->
                    
                    <br><h3>Question 1.</h3><br>
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <textarea name="title1" class="form-control" id="" cols="15" rows="2" placeholder="Question title"></textarea>
                        </div>
                    </div><br>
                    <button class="btn btn-success" id="Add1">Add a new question</button> 
                    <button class="btn btn-danger" id="Remove1">Remove a question</button>  
                    <div id="textboxDiv1"></div> <br>
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                      <br><h3>Question 2.</h3><br>
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <textarea name="title1" class="form-control" id="" cols="15" rows="2" placeholder="Question title"></textarea>
                        </div>
                    </div><br>
                    <button class="btn btn-success" id="Add2">Add a new question</button> 
                    <button class="btn btn-danger" id="Remove2">Remove a question</button>  
                    <div id="textboxDiv2"></div> <br>
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                      <br><h3>Question 3.</h3><br>
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <textarea name="title1" class="form-control" id="" cols="15" rows="2" placeholder="Question title"></textarea>
                        </div>
                    </div><br>
                    <button class="btn btn-success" id="Add3">Add a new question</button> 
                    <button class="btn btn-danger" id="Remove3">Remove a question</button>  
                    <div id="textboxDiv3"></div> <br>
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                      <br><h3>Question 4.</h3><br>
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <textarea name="title1" class="form-control" id="" cols="15" rows="2" placeholder="Question title"></textarea>
                        </div>
                    </div><br>
                    <button class="btn btn-success" id="Add4">Add a new question</button> 
                    <button class="btn btn-danger" id="Remove4">Remove a question</button>  
                    <div id="textboxDiv4"></div> <br>
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                      <br><h3>Question 5.</h3><br>
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <textarea name="title1" class="form-control" id="" cols="15" rows="2" placeholder="Question title"></textarea>
                        </div>
                    </div><br>
                    <button class="btn btn-success" id="Add5">Add a new question</button> 
                    <button class="btn btn-danger" id="Remove5">Remove a question</button>  
                    <div id="textboxDiv5"></div> <br>
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------   <br>
                      
<input class="btn btn-default" value="Submit Paper"><br><br>
                    
                    <!-- paper entry end -->   
                    
                </div>
            </div>
        </div>

    </div>
    
    <select name="" id="">
        <option value=""></option>
    </select>
    <script>
function myFunction() {
    var myWindow = window.open("", "", "width=800,height=600");
    myWindow.document.write("<html><head><title>AWS</title><link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'></head><body><br><form method='POST' action='includes/sel_que.php'><div class='row'><div class='col-sm-2'><select name='branch' class='form-control'><option value='it'>IT</option><option value='comps'>COMPS</option></select></div><div class='col-sm-2'><input type='text' class='form-control' name='sem' placeholder='semester'></div><div class='col-sm-2'><input type='text' class='form-control' name='co' placeholder='CO number'></div><div class='col-sm-2'><input type='text' class='form-control' placeholder='marks' name='marks'></div><input type='submit' class='btn btn-success' name='search' value='Search'></div></form><br><form><div class='row'><div class='col-sm-4'><label for=''>search </label><input type='text' class='form-control' size='30' onkeyup='showResult(this.value)'><div id='livesearch'></div></div></div></form><br><table class='table'><thead><th>sr. no.</th><th>question</th><th>Marks</th></thead><tbody><tr><td>1</td><td>Give ful form of IP</td></tr><tr><td>2</td><td>When was JavaScript founded?</td></tr></tbody></table></body></html>");
}

        // js for 1st que entry
        $(document).ready(function() {  
            $("#Add1").on("click", function() {  
                $("#textboxDiv1").append("<br><div class='row'><div class='col-sm-1'><select class='form-control' name='' id=''><option value=''>--</option><option value=''>1a</option><option value=''>1b</option><option value=''>1c</option><option value=''>1d</option><option value=''>1e</option><option value=''>1f</option><option value=''>1g</option></select></div><div class='col-sm-4'><textarea class='form-control' placeholder='question'></textarea></div><div class='col-sm-0.5'><p><b>marks: <b></p></div><div class='col-sm-2'><input class='form-control'></div><buttton onclick='myFunction()' class='btn btn-warning'>OPEN</button></div>");  
            });  
            $("#Remove1").on("click", function() {  
                $("#textboxDiv1").children().last().remove();  
            });  
        }); 
        
        // js for 2nd que entry
        $(document).ready(function() {  
            $("#Add2").on("click", function() {  
                $("#textboxDiv2").append("<br><div class='row'><div class='col-sm-1'><select class='form-control' name='' id=''><option value=''>--</option><option value=''>1a</option><option value=''>1b</option><option value=''>1c</option><option value=''>1d</option><option value=''>1e</option><option value=''>1f</option><option value=''>1g</option></select></div><div class='col-sm-4'><textarea class='form-control' placeholder='question'></textarea></div><div class='col-sm-0.5'><p><b>marks: <b></p></div><div class='col-sm-2'><input class='form-control'></div><buttton onclick='myFunction()' class='btn btn-warning'>OPEN</button></div>");  
            });  
            $("#Remove2").on("click", function() {  
                $("#textboxDiv2").children().last().remove();  
            });  
        });
        
        // js for 3rd que entry
        $(document).ready(function() {  
            $("#Add3").on("click", function() {  
                $("#textboxDiv3").append("<br><div class='row'><div class='col-sm-1'><select class='form-control' name='' id=''><option value=''>--</option><option value=''>1a</option><option value=''>1b</option><option value=''>1c</option><option value=''>1d</option><option value=''>1e</option><option value=''>1f</option><option value=''>1g</option></select></div><div class='col-sm-4'><textarea class='form-control' placeholder='question'></textarea></div><div class='col-sm-0.5'><p><b>marks: <b></p></div><div class='col-sm-2'><input class='form-control'></div><buttton onclick='myFunction()' class='btn btn-warning'>OPEN</button></div>");  
            });  
            $("#Remove3").on("click", function() {  
                $("#textboxDiv3").children().last().remove();  
            });  
        });
        
        // js for 4th que entry
        $(document).ready(function() {  
            $("#Add4").on("click", function() {  
                $("#textboxDiv4").append("<br><div class='row'><div class='col-sm-1'><select class='form-control' name='' id=''><option value=''>--</option><option value=''>1a</option><option value=''>1b</option><option value=''>1c</option><option value=''>1d</option><option value=''>1e</option><option value=''>1f</option><option value=''>1g</option></select></div><div class='col-sm-4'><textarea class='form-control' placeholder='question'></textarea></div><div class='col-sm-0.5'><p><b>marks: <b></p></div><div class='col-sm-2'><input class='form-control'></div><buttton onclick='myFunction()' class='btn btn-warning'>OPEN</button></div>");  
            });  
            $("#Remove4").on("click", function() {  
                $("#textboxDiv4").children().last().remove();  
            });  
        });
        
        // js for 5th que entry
        $(document).ready(function() {  
            $("#Add5").on("click", function() {  
                $("#textboxDiv5").append("<br><div class='row'><div class='col-sm-1'><select class='form-control' name='' id=''><option value=''>--</option><option value=''>1a</option><option value=''>1b</option><option value=''>1c</option><option value=''>1d</option><option value=''>1e</option><option value=''>1f</option><option value=''>1g</option></select></div><div class='col-sm-4'><textarea class='form-control' placeholder='question'></textarea></div><div class='col-sm-0.5'><p><b>marks: <b></p></div><div class='col-sm-2'><input class='form-control'></div><buttton onclick='myFunction()' class='btn btn-warning'>OPEN</button></div>");  
            });  
            $("#Remove5").on("click", function() {  
                $("#textboxDiv5").children().last().remove();  
            });  
        });
</script>

    <!-- Jquery JS-->
    <script src="vendor/jquery-3.2.1.min.js"></script>
<?php include "script.php"; ?>
    <!-- Main JS-->
    <script src="js/main.js"></script>

</body>

</html>
<!-- end document-->
