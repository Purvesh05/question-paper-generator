# HTML to PDF
Create Downloadable PDF file from HTML in a easy way<br/> 
<b>To know how it works just watch this 2 minutes video - https://youtu.be/_EqYMNdbrsc</b>
