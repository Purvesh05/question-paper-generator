<?php

$servername = "localhost";
$username = "root";
$password = "";
$db = "aws";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $db);


if(isset($_POST['search'])){
    
    $branch = $_POST['branch'];
    $sem = $_POST['sem'];
    $co = $_POST['co'];
    $marks = $_POST['marks'];
    $table = $branch.$sem;
    
    
    $query = "SELECT * FROM `$table` WHERE sem='$sem' and marks='$marks'";
    $result = mysqli_query($conn, $query);
    
    if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $row['quest'] . "</td>";
        echo "</tr>";
        
    }
} else {
    echo "0 results";
}
    
 
    
    
}

mysqli_close($conn);

?>
