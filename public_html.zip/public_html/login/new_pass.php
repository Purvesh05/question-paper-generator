<?php 
ob_start();
session_start();
if(isset($_POST['submit'])){
	
		include("../includes/db.php");
	$passowrd = mysqli_real_escape_string($conn,$_POST['new_pass']);
	 $passowrd = password_hash($passowrd,PASSWORD_BCRYPT,array('cost'=>10));	
	
	 $email = $_SESSION['email'];
	
	$query = "update `teacher` set password = ' $passowrd' where email = '$email'";
	
	$update_query = mysqli_query($conn,$query);
if(!$update_query){
	die (mysqli_error($conn));
}else{
	echo "changed";
}
	
	$query = "update `teacher` set token = '0' where email = '$email'";
	$update_query = mysqli_query($conn,$query);
if(!$update_query){
	die (mysqli_error($conn));
}
}



?>



<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	
	
	<form action="" method="post">
		
		<input type="password" name="new_pass" id="new_pass">	
		<button type="submit" name="submit">Submit</button>	
		
		
	</form>
	
	
	
</body>
</html>