<?php
ob_start();
session_start();
include("../includes/db.php");
if(isset($_GET['token'] , $_GET['email'])){
	
	
	echo $email = mysqli_real_escape_string($conn,$_GET['email']);
	 echo $token = mysqli_real_escape_string($conn,$_GET['token']);
	
	$query = "SELECT * FROM `teacher` WHERE `token` = '$token'  and email = '$email'";
	

	
	$select_query = mysqli_query($conn, $query);
	$count = mysqli_num_rows($select_query);
	if($count > 0 ){
		
		$_SESSION['email'] = $email;
		header("Location:new_pass.php");
	
		
	}else{
		echo " Plesase check your input";
		
	}
	

}elseif($token = '0'){
		echo "reset pass link expried";
	
}else{
	echo "Something went wrong plz try again";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	




</body>
</html>
